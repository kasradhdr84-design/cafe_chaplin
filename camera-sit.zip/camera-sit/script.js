const video = document.getElementById("video");
const canvas = document.getElementById("canvas");
const captureBtn = document.getElementById("capture");

async function startCamera() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({
            video: true
        });

        video.srcObject = stream;
    } catch (error) {
        alert("اجازه دسترسی به دوربین داده نشد.");
    }
}

startCamera();

captureBtn.addEventListener("click", () => {

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext("2d");

    ctx.drawImage(video, 0, 0);

    const image = canvas.toDataURL("image/png");

    const link = document.createElement("a");

    link.href = image;
    link.download = "photo.png";

    link.click();
link.click();

const msg = document.getElementById("thanksMessage");

msg.style.display = "block";

setTimeout(() => {
    msg.style.display = "none";
}, 5000);

});